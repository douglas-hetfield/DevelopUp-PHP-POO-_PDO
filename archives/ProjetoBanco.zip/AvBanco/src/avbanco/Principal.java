package avbanco;

import javax.swing.JOptionPane;

public class Principal {
    public static void main(String[] args) {
        Cliente c = new Cliente();
        int opc = -1, variavel = 1;
        int option;
        
        c.setAtivo(true);
        c.setDataCadastro("11/09/2017");
        
        while(variavel == 1){
            c.setNome(JOptionPane.showInputDialog("Digite seu nome: "));
            c.setCpf(JOptionPane.showInputDialog("Digite seu cpf: "));
            c.setEndereco(JOptionPane.showInputDialog("Digite seu endereço: "));
            c.setNumero(JOptionPane.showInputDialog("Digite seu numero: "));
            c.setComplemento(JOptionPane.showInputDialog("Digite seu complemento: "));
            c.setLogin(JOptionPane.showInputDialog("Digite seu login: "));
            c.setPws(JOptionPane.showInputDialog("Digite sua senha: "));
        
            if(c.isPessoa() != ""){
                JOptionPane.showMessageDialog(null, "Erros:\n" + c.isPessoa());
                variavel = 1;
            }else{
            
                variavel = JOptionPane.showConfirmDialog(null, "nome: " + c.getNome() + "\n"
                        + "cpf: " + c.getCpf() + "\n"
                        + "endereço: " + c.getEndereco() + "\n"
                        + "numero: " + c.getNumero() + "\n"
                        + "complemento: " + c.getComplemento() + "\n"
                        + "login: " + c.getLogin() + "\n"
                        + "senha: " + c.getPws() + "\n");

            }
            
        }
        
        if(variavel == 2){
            opc = 0;
        }
         
        ContaCorrente conta = new ContaCorrente(JOptionPane.showInputDialog("numero da conta: "), Float.parseFloat(JOptionPane.showInputDialog("Limite de crédito: ")), 0, c);
        
        
        while(opc != 0){
            try{
                opc = Integer.parseInt(JOptionPane.showInputDialog(""+
                    "nome: " + c.getNome() + "\n"
                    + "login: " + c.getLogin() + "\n"
                    + "numero da conta: " + conta.getNumeroConta()+ "\n"
                    + "Limite de credito: " + conta.getLimiteCredito()+ "\n"
                    + "saldo: " + conta.getSaldo() + "\n"
                                                  
                    + "\n"
                    + "[1] Saque \n"
                    + "[2] Depositar \n"
                    + "[0] Finalizar"));
            
                        switch(opc){
                            case 1:
                                conta.saque(Float.parseFloat(JOptionPane.showInputDialog("Valor do saque: ")));
                                break;
                            case 2:
                                conta.deposito(Float.parseFloat(JOptionPane.showInputDialog("valor do deposito: ")));
                                break;
                            case 0:
                                JOptionPane.showMessageDialog(null, "Finalizado com sucesso.");
                                break;
                        }
            }catch (NumberFormatException err) {
                System.err.println("Erro: " + err.toString());
                JOptionPane.showMessageDialog(null, "Digite apenas numeros.");
                opc = -1;
            }
                
        }
    }
    
}
