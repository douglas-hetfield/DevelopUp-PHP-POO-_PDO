/*
b. Métodos : GETs e SETs, depósito e saque, e validação de campos;
c. Crie um construtor, saldo é opcional, com valor default(padrão) zero e os demais atributos são
obrigatórios.
d. Vincule um Cliente do exercício anterior (Classe Cliente) ao nosso programa. Para que cada Cada
conta tenha apenas um cliente. Adicione esta funcionalidade ao construtor.*/

package avbanco;

import javax.swing.JOptionPane;

public class ContaCorrente {
    private String numeroConta;
    private float limiteCredito;
    private float saldo;
    private Cliente cliente;

    public ContaCorrente(String numeroConta, float limiteCredito, float saldo, Cliente c) {
        this.numeroConta = numeroConta;
        this.limiteCredito = limiteCredito;
        this.saldo = 0;
        this.cliente = c;
    }

    public String getNumeroConta() {
        return numeroConta;
    }

    public void setNumeroConta(String numeroConta) {
        this.numeroConta = numeroConta;
    }

    public float getLimiteCredito() {
        return limiteCredito;
    }

    public void setLimiteCredito(float limiteCredito) {
        this.limiteCredito = limiteCredito;
    }

    public float getSaldo() {
        return saldo;
    }

    public void setSaldo(float saldo) {
        this.saldo = saldo;
    }
    
    public void deposito(float valor){
        this.setSaldo(this.getSaldo() + valor);
    }
    
    public void saque(float valorSaque){
        if(this.getSaldo() + this.getLimiteCredito() >= valorSaque){
            this.setSaldo(this.getSaldo() - valorSaque);
            JOptionPane.showMessageDialog(null, "Saque realizado com sucesso!");
        }else{
            JOptionPane.showMessageDialog(null, "você não possui saldo suficiente para esta operação!");
        }
    }
    
    
    public String isContaCorrente() {
        String erros = "";

        if (getNumeroConta().equals("")) {
            erros += "Nome em branco.\n";
        }
        return erros;
    }
}