package avbanco;
public abstract class Pessoa {
    private String nome;
    private String cpf;
    private String endereco;
    private String numero;
    private String complemento;
    private String login;
    private String pws;
    

    public Pessoa() {
        
    }

     public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public String getNumero() {
        return numero;
    }

    public void setNumero(String numero) {
        this.numero = numero;
    }

    public String getComplemento() {
        return complemento;
    }

    public void setComplemento(String complemento) {
        this.complemento = complemento;
    }
    
    public String getLogin (){
        return login;
    }
    
    public void setLogin (String login){
        this.login = login;
    }

    public String getPws() {
        return pws;
    }

    public void setPws(String pws) {
        this.pws = pws;
    }
    
    public String isPessoa() {
        String erros = "";

        if (getNome().equals("")) {
            erros += "Nome em branco.\n";
        }

        if (cpf.equals("")) {
            erros += "CPF em branco.\n";
        }
        
        if(endereco.equals("")){
            erros += "Endereço em branco. \n";
        }

        if (numero.equals("")) {
            erros += "Numero em branco.\n";
        }
        
        if(complemento.equals("")){
            erros += "Complemento em branco. \n";
        }
        
        if(login.equals("")){
            erros += "Login em branco. \n";
        }

        return erros;
    }

    public String isSenha(String confirmaSenha) {
        String erros = "";
        if (this.getPws().equals("")) {
            erros += "Senha em branco.\n";
        } else if (this.getPws().length() < 7) {
            erros += "Senha é muito curta. Minimo de 8(seis) caracteres \n";
        } else if (!pws.equals(confirmaSenha)) {
            erros += "Senhas diferentes\n";
        }
        return erros;
    }

    public String isPessoa(String confirmaSenha) {
        return isPessoa() + isSenha(confirmaSenha);
    }
 
}
