package avbanco;
public class Cliente extends Pessoa {
    private boolean ativo;
    private String dataCadastro;

    public Cliente() {
    }
    
    public Cliente(boolean ativo, String dataCadastro) {
        this.ativo = true;
        this.dataCadastro = "";
    }

    
    public boolean getAtivo() {
        return ativo;
    }

    public void setAtivo(boolean ativo) {
        this.ativo = ativo;
    }

    public String getDataCadastro() {
        return dataCadastro;
    }

    public void setDataCadastro(String dataCadastro) {
        this.dataCadastro = dataCadastro;
    }
    
    public String isCliente(){
        String erro = "";
        
        if(dataCadastro.equals("")){
            erro += "Data do cadastro está em Branco";
        }
        return erro;
    }
    
}
