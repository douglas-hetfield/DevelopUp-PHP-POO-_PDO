package br.edu.tamagushi.model;

public class Tamagushi {

    private String nome;
    private int fome;
    private int saude;
    private int idade;

    public Tamagushi(String nome) {
        this.nome = nome;
        fome = 25;
        saude = 25;
        idade = 1;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getFome() {
        return fome;
    }

    public void setFome(int fome) {
        this.fome = fome;
    }

    public int getSaude() {
        return saude;
    }

    public void setSaude(int saude) {
        this.saude = saude;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public float getHumor() {
        return (fome + saude) / 2;
    }

   
}
