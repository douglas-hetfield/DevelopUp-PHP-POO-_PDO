package br.edu.tamagushi.controller;

import br.edu.tamagushi.model.Tamagushi;

public class CtrlTamagushi {

    public void alimentar(Tamagushi tama, int i) {
        if (tama.getFome() > 0 && tama.getFome() < 100) {
            if ((tama.getFome() + i) < 100) {
                tama.setFome(tama.getFome() + i);
            } else {
               tama.setFome(100);
            }
        }
    }
    public void cuidar(Tamagushi tama, int i) {
        if (tama.getSaude()> 0 && tama.getSaude()< 100) {
            if ((tama.getSaude()+ i) < 100) {
                tama.setSaude(tama.getSaude()+ i);
            } else {
               tama.setSaude(100);
            }
        }
    }

}
